from sqlalchemy.orm import Session

from app.models.user import User


class UserRepository:

    @staticmethod
    def get_by_email(db: Session, email: str):
        return db.query(User).filter(User.email == email).first()

    @staticmethod
    def create(
        db: Session,
        full_name: str,
        email: str,
        password_hash: str
    ):
        user = User(
            full_name=full_name,
            email=email,
            password_hash=password_hash
        )

        db.add(user)
        db.flush()

        return user

    @staticmethod
    def authenticate(
        db: Session,
        email: str
    ):
        return db.query(User).filter(
            User.email == email
        ).first()
